
from calibre.ebooks.metadata.sources.base import Source
from calibre.ebooks.metadata.book.base import Metadata as CalibreMetadata


class FakeSource(Source):
    name = "Fake Source"
    id = "fakesrc"
    version = (1, 0, 0)
    description = "Fake calibre metadata source for tests."
    capabilities = frozenset({"identify"})

    def search(self, title="", authors=None, isbn="", timeout=15.0):
        results = []
        for t, i in (("Fake Book One", "9780306406157"), ("Fake Book Two", "9780132350884")):
            m = CalibreMetadata(t, ["Test Author"])
            m.set_identifier("isbn", i)
            m.publisher = "Fake Publisher"
            m.tags = ["fake"]
            results.append(m)
        return results

    def identify(self, log, result_queue, abort, title=None, authors=None,
                 identifiers=None, timeout=30):
        for m in self.search(title=title or ""):
            result_queue.put(m)
